# Installation Guide - Universal Language Codex

## For Different AI Platforms

### GitHub Copilot / VS Code
1. Copy `github-copilot/github-copilot-codex.json` to your project
2. In VS Code, create a new file and import:
   ```javascript
   const codex = require('./github-copilot-codex.json');
   ```
3. Access translations: `codex.codex_data.universal_constructs`

### OpenAI API / ChatGPT
1. Use `openai-api/openai-codex.json` as system context
2. Include in your API calls:
   ```python
   import json
   with open('openai-codex.json') as f:
       codex = json.load(f)
   
   # Add to system prompt
   system_prompt = codex['system_prompt']
   ```

### Claude API
1. Load `claude-api/claude-codex.json`
2. Include codex data in your Claude conversations
3. Claude can handle the full context due to large context window

### Perplexity API
1. Use `perplexity-api/perplexity-codex.json`
2. Include as context for enhanced search and translation

### Python Projects
1. Copy `python-module/universal_codex.py` to your project
2. Import and use:
   ```python
   from universal_codex import translate, get_languages
   
   # Translate between any languages
   result = translate("print('hello')", "python", "koraelin")
   
   # List all available languages
   languages = get_languages()
   ```

### JavaScript/Node.js Projects
1. Copy `javascript-module/universal-codex.js` to your project
2. Import and use:
   ```javascript
   const { translator } = require('./universal-codex');
   
   // Translate between any languages
   const result = translator.translate("console.log('hello')", "javascript", "avali");
   
   // List all available languages
   const languages = translator.listLanguages();
   ```

### Universal JSON (Any Platform)
1. Use `universal-codex.json` for any system that can read JSON
2. Parse the JSON and access:
   - `programming_languages` - Programming language data
   - `sacred_tongues` - Sacred Tongue data
   - `universal_constructs` - Translation mappings
   - `concept_bridges` - Cross-domain concept mapping

## Troubleshooting
- **Import errors**: Ensure file paths are correct
- **Translation not found**: Check if the exact text exists in constructs
- **Sacred Tongue warnings**: Some constructs have magical warnings (e.g., Runethic)

## Advanced Usage
- Combine with AI Neural Spine for learning and adaptation
- Use Universal Bridge for multi-language communication
- Extend with your own language constructs
