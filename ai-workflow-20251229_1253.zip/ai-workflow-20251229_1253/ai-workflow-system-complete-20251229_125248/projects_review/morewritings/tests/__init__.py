"""Test package initialization."""
