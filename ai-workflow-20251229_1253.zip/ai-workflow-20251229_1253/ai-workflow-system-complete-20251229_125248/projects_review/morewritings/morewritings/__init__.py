"""
Morewritings - A creative writing scene generation tool.
"""

__version__ = "0.1.0"
