#!/usr/bin/env python3
"""
Morewritings CLI entry point.
"""
from morewritings.cli import cli

if __name__ == "__main__":
    cli()
