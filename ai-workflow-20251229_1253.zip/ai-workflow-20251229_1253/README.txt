# AI Workflow System Distribution Package

## Quick Start

1. Install Python dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Start the AI system:
   ```
   cd app-productizer
   python evolving_ai_main.py
   ```

3. Start web interface:
   ```
   cd app-productizer  
   python web_interface.py
   ```

## Package Contents

- **Files**: 1686
- **Size**: 17.57 MB
- **Created**: 2025-12-29 12:53

## Components

- Self-Evolving AI Framework (app-productizer/)
- AI Workflow Architect (projects_review/)
- Bridge API (bridge-api/)
- Documentation (*.md files)
- Tests and utilities

## Support

See the included documentation files for detailed setup instructions.
