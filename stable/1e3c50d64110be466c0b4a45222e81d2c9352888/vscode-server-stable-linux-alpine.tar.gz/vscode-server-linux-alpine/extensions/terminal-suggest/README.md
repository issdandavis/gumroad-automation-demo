# Terminal Suggestions

**Notice:** This extension is bundled with Visual Studio Code. It can be disabled but not uninstalled. To enable the completions from this extension, set `terminal.integrated.suggest.enabled` to `true`.

## Features

Provides terminal suggestions for zsh, bash, fish, and pwsh.
